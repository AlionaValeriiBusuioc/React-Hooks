import React, {useState, useEffect} from 'react';

export default function UseEffectModel() {
    // const [resourceType, setResourceType] = useState('posts')
    const [windowWidth, setwindowWidth] = useState(window.innerWidth)
    const [items, setItems] = useState([])
   
    // useEffect (() => {
    //     fetch(`https://jsonplaceholder.typicode.com/${resourceType}`)
    //     .then((response) => response.json())
    //     // .then((json) => console.log(json))
    //     .then((json) => setItems(json))
    // }, [resourceType])

    const handleResize = () => {
        setwindowWidth(window.innerWidth)
    }

    useEffect(() =>{
    window.addEventListener('resize', handleResize)
    return () => {
        window.removeEventListener('resize', handleResize)
    }
    }, [])
    
    return(
        <div>{windowWidth}
        {/* <div>
            <button onClick={() => setResourceType('posts')}>Posts</button>
            <button onClick={() => setResourceType('users')}>Users</button>
            <button onClick={() => setResourceType('comments')}>Comments</button>
        </div>
    <h1>{resourceType}</h1>
    {items.map(item => {
        return <pre>{JSON.stringify(item)}</pre>
    })} */}
       
        </div>
    )
}