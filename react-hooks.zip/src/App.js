import React from 'react';
import UseState from './UseState';
import UseEffectModel from './UseEffectModel';
import UseEffect from './UseEffect';
import UseMemo from './UseMemo';
import UseRef from './UseRef';
import UseContext from './UseContext';
import UseReducer from './UseReducer';
import UseReducerModel from './UseReducerModel';
import UseCallback from './UseCallback';
import CustomHooks from './CustomHooks';

function App() {
  return (
    <>
    <UseState/>
    <UseEffectModel/>
    <UseEffect/>
    <UseMemo/>
    <UseRef/>
    <UseContext/>
    <UseReducer/>
    <br/><br/>
    <UseReducerModel/>
    <br/><br/>
    <UseCallback/>
    <br/><br/>
    <CustomHooks/>
    </>
  );
}

export default App;
