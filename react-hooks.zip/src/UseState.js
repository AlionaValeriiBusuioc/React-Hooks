import React, { useState } from 'react';

// function countInitial(){
//     console.log('run function')
//     return 4
// }

 const UseState = () => {
     //hook-urile se pun in partea de sus a componentei functie
    // const [count, setCount] = useState(4)
    // const [count, setCount] = useState(() => countInitial())
    // setCount - se utilizeaza pentru update State
    // const [state, setState] = useState({count: 4, theme: 'blue'})
    //cu useState -> noi putem sa definim diferite portiuni de State, pentru fiecare bucata care avem nevoie 
    const [count, setCount] = useState(4)
    const [theme, setTheme] = useState('blue')
    // const count = state.count
    // const theme = state.theme 
    function decrementCount(){
        setCount(prevCount => prevCount-1)
    }
    function incrimentCount(){
        setCount(prevCount => prevCount+1)
        setTheme('red')
    }
    // function decrementCount(){
    //     setState(prevState => {
    //         return { ...prevState, count: prevState.count -1} 
    //     }) 
    // }
    // function incrimentCount(){
    //     setState(prevState => {
    //         return { ...prevState, count: prevState.count +1} 
    //     }) 
    // }
        return (
            <>
           <button onClick={decrementCount}>-</button>
        <span>{count}</span>
        <span>{theme}</span>
           <button onClick={incrimentCount}>+</button>
            </>
        )
    }


export default UseState;
