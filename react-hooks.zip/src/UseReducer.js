import React, { useReducer } from 'react';

const ACTIONS = {
    INCREMENT: 'increment',
    DECREMENT: 'decrement'
}

// function reducer(state, action) {
// switch (action.type) {
//     case 'increment' : 
//     return {count: state.count + 1}
//     case 'decrement' :
//     return {count: state.count - 1}    
//     default:
//     return state    
//  }   
// }

function reducer(state, action) {
    switch (action.type) {
        case ACTIONS.INCREMENT : 
        return {count: state.count + 1}
        case ACTIONS.DECREMENT :
        return {count: state.count - 1}    
        default:
        return state    
     }   
    }

export default function UseReducer() {
const [state, dispatch] = useReducer(reducer, {count: 0})   
// const [count, setCount] =useState(0)

// function increment(){
//     setCount(prevCount => prevCount + 1)
// }
// function decrement() {
//     setCount(prevCount => prevCount -1)
// }
// function increment(){
//     dispatch({type: 'increment'})
// }
// function decrement() {
//     dispatch({type: 'decrement'})
// }
function increment(){
    dispatch({type: ACTIONS.INCREMENT})
}
function decrement() {
    dispatch({type: ACTIONS.DECREMENT})
}
return(
    <>
    <button onClick={decrement}>-</button>
    {/* <span>{count}</span> */}
    <span>{state.count}</span>
    <button onClick={increment}>+</button>
    </>
)
}