import React, {useState, useEffect, useRef} from 'react';

export default function UseRef(){
    const [name, setName] = useState('')
    // const renderCount = useRef(0)
    // const inputRef = useRef()
    const prevName = useRef('')
    

// useEffect(() => {
//    renderCount.current = renderCount.current + 1 
// })
// function focus() {
//     inputRef.current.focus()
//     inputRef.current.value = 'Some value'
// }
useEffect(() => {
 prevName.current = name
}, [name])

    return(
        <>
        {/* <input ref={inputRef} value={name} onChange={e => setName(e.target.value)}/> */}
        <input value={name} onChange={e => setName(e.target.value)}/>
    <div>My name is {name} and it used to be {prevName.current}</div>
    {/* <div>I rendered {renderCount.current} times</div> */}
    {/* <button onClick={focus}>Focus</button> */}
        </>
    )
}